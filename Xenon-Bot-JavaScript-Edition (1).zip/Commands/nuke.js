const Discord = require('discord.js');

module.exports = class nuke {
    constructor() {
        this.name = "nuke",
        this.alias = [""],
        this.usage = "q.nuke"
       }

    async run(client, message, args) {
        if (!message.member.hasPermission("ADMINISTRATOR")){
        //You can change the Permission it requires to something else//
            return message.channel.send("You dont have the permission to use this commands!")
        }
        let reason = args.join(" ") || "No Reason :/"
        if(!message.channel.deletable) {
            return message.reply("This channel cannot be nuked bruh :/")
        }
        let newchannel = await message.channel.clone()
        const position = message.channel.position;
        await newchannel.setPosition(position)
        await message.channel.delete()
        await send.newEmbed(newchannel)
      } 
} 