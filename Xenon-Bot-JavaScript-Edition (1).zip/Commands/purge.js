const { RichEmbed } = require("discord.js");

module.exports = class purge {
    constructor() {
        this.name = "purge",
        this.alias = [""],
        this.usage = "q.purge"
    }


     async run(bot, message, arg) {
        if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("You Don't Have Sufficient Permissions!- [MANAGE_MESSAGES]")
        if (isNaN(arg.parseInt()))
            return message.channel.send('**Please Supply A Valid Amount To Delete Messages!**');

        if (arg.parseInt() > 100)
            return message.channel.send("**Please Supply A Number Less Than 100!**");

        if (arg.parseInt() < 1)
            return message.channel.send("**Please Supply A Number More Than 1!**");

        message.channel.bulkDelete(arg.parseInt())
            .then(messages => message.channel.send(`**Succesfully deleted \`${messages.size}/${arg.parseInt()}\` messages**`).then(msg => msg.delete({ timeout: 5000 }))).catch(() => null)
    }
}